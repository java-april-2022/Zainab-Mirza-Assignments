package com.zainab.test;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MvcTestApplicationTests {

	@Test
	void contextLoads() {
	}

}
